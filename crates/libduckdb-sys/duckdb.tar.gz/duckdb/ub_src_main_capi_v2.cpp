#include "src/main/capi/v2/capi_v2.cpp"

#include "src/main/capi/v2/capi_v2_arena.cpp"

#include "src/main/capi/v2/capi_v2_arrow.cpp"

#include "src/main/capi/v2/capi_v2_catalog.cpp"

#include "src/main/capi/v2/capi_v2_column_data_collection.cpp"

#include "src/main/capi/v2/capi_v2_config.cpp"

#include "src/main/capi/v2/capi_v2_connection.cpp"

#include "src/main/capi/v2/capi_v2_custom_option.cpp"

#include "src/main/capi/v2/capi_v2_custom_type.cpp"

#include "src/main/capi/v2/capi_v2_data_chunk.cpp"

#include "src/main/capi/v2/capi_v2_environment.cpp"

#include "src/main/capi/v2/capi_v2_error.cpp"

#include "src/main/capi/v2/capi_v2_expression.cpp"

#include "src/main/capi/v2/capi_v2_extension.cpp"

#include "src/main/capi/v2/capi_v2_factory.cpp"

#include "src/main/capi/v2/capi_v2_file_system.cpp"

#include "src/main/capi/v2/capi_v2_func.cpp"

#include "src/main/capi/v2/capi_v2_func_aggregate.cpp"

#include "src/main/capi/v2/capi_v2_func_cast.cpp"

#include "src/main/capi/v2/capi_v2_func_copy.cpp"

#include "src/main/capi/v2/capi_v2_func_docs.cpp"

#include "src/main/capi/v2/capi_v2_func_macro.cpp"

#include "src/main/capi/v2/capi_v2_func_pragma.cpp"

#include "src/main/capi/v2/capi_v2_func_properties.cpp"

#include "src/main/capi/v2/capi_v2_func_scalar.cpp"

#include "src/main/capi/v2/capi_v2_func_signature.cpp"

#include "src/main/capi/v2/capi_v2_func_table.cpp"

#include "src/main/capi/v2/capi_v2_identifier.cpp"

#include "src/main/capi/v2/capi_v2_instance.cpp"

#include "src/main/capi/v2/capi_v2_log_sink.cpp"

#include "src/main/capi/v2/capi_v2_logging.cpp"

#include "src/main/capi/v2/capi_v2_logical_type.cpp"

#include "src/main/capi/v2/capi_v2_option.cpp"

#include "src/main/capi/v2/capi_v2_prepared_statement.cpp"

#include "src/main/capi/v2/capi_v2_qname.cpp"

#include "src/main/capi/v2/capi_v2_query_metrics.cpp"

#include "src/main/capi/v2/capi_v2_replacement_scan.cpp"

#include "src/main/capi/v2/capi_v2_result.cpp"

#include "src/main/capi/v2/capi_v2_schema.cpp"

#include "src/main/capi/v2/capi_v2_statement.cpp"

#include "src/main/capi/v2/capi_v2_stats.cpp"

#include "src/main/capi/v2/capi_v2_stubs.cpp"

#include "src/main/capi/v2/capi_v2_tokenizer.cpp"

#include "src/main/capi/v2/capi_v2_utf8.cpp"

#include "src/main/capi/v2/capi_v2_value.cpp"

#include "src/main/capi/v2/capi_v2_vector.cpp"

